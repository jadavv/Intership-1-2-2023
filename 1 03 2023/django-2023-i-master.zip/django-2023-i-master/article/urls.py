from django.contrib import admin
from django.urls import path,include
from blog.views import home
#from blog import views

urlpatterns = [
    
]